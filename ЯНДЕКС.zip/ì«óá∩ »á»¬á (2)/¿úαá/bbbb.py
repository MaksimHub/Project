import pygame

pygame.init()
win = pygame.display.set_mode((1200, 720))

pygame.display.set_caption('Квадрат')

walkLeft  = [pygame.image.load('left_1.png'),
             pygame.image.load('left_2.png'), pygame.image.load('left_3.png'),
             pygame.image.load('left_4.png'), pygame.image.load('left_5.png'),
             pygame.image.load('left_6.png')]

walkRight = [pygame.image.load('right_1.png'),
             pygame.image.load('right_2.png'), pygame.image.load('right_3.png'),
             pygame.image.load('right_4.png'), pygame.image.load('right_5.png'),
             pygame.image.load('right_5.png')]

bg = pygame.image.load('bg.jpg')
playerStand = pygame.image.load('idle.png')

clock = pygame.time.Clock()

x = 90
y = 0
width = 1200
height = 71
speed = 15


isJump = False
jumpCount = 10

left = False
right = False
aniCount = 0
lastMove = 'right'
lastMove1 = 'left'


class snaryad():
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing

    def draw(self, win):
        pygame.draw.circle(win, self.color, (self.x, self.y), self.radius)


def draindow():
    global aniCount
    win.blit(bg, (0, 0))

    if aniCount + 1 >= 30:
        aniCount = 0

    if left:
        win.blit(walkLeft[aniCount // 5], (x, y))
        aniCount += 1
    elif right:
        win.blit(walkRight[aniCount // 5], (x, y))
        aniCount += 1
    else:
        win.blit(playerStand, (x, y))

    for bullet in bullets:
        bullet.draw(win)

    pygame.display.update()


run = True
bullets = []
while run:
    clock.tick(30)

    for eve in pygame.event.get():
        if eve.type == pygame.QUIT:
            run = False

    for bullet in bullets:
        if bullet.x < 1200 > 0:
            bullet.x += bullet.vel
        else:
            bullets.pop(bullets.index(bullet))

    keys = pygame.key.get_pressed()

    if keys[pygame.K_f]:
        if lastMove == 'right':
            facing = -1
        elif lastMove1 == 'left':
            facing = 1

        if keys[pygame.K_g]:
            if lastMove1 == 'left':
                facing = 1

        if len(bullets) < 29:
            bullets.append(snaryad(round(x + width // 2), round(y + height // 2), 7, (255, 0, 0), facing))

    if keys[pygame.K_LEFT] and x > 5:
        x -= speed
        left = True
        right = False
    elif keys[pygame.K_RIGHT] and x < 1200:
        x += speed
        left = False
        right = True
    else:
        left = False
        right = False
        aniCount = 0
    if isJump:
        if keys[pygame.K_SPACE]:
            isJump = False
    if isJump:
        if keys[pygame.K_UP]:
            isJump = False
    else:
        if jumpCount >= -10:
            if jumpCount < 0:
                y += (jumpCount ** 2) / 2
            else:
                y -= (jumpCount ** 2) / 2
            jumpCount -= 1
        else:
            isJump = True
            jumpCount = 10

    draindow()
