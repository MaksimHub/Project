import pygame
import random
import sys
import time
from pygame.locals import *

import os
import time
import speech_recognition as sr
from fuzzywuzzy import fuzz
import pyttsx3
import datetime


def command():
    r = sr.Recognizer()

    with sr.Microphone() as source:
        print("Говорите")
        r.pause_threshold = 1
        r.adjust_for_ambient_noise(source, duration=1)
        audio = r.listen(source)

    try:
        task = r.recognize_google(audio, language="ru-RU").lower()
        print("открываю " + task)
    except:
        task = command()
    return task


def makeSomething(task):
    print(task)
    if "время" in task:
        now = datetime.datetime.now()
        print("Сейчас " + str(now.hour) + ":" + str(now.minute))
    elif "таблица" in task:
        os.startfile(r"C:\Users\Daniya\PycharmProjects\untitled3\dist\xxx.exe")
    elif "интернет" in task:
        os.startfile(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")
    elif "minecraft" in task:
        os.startfile(r"C:\Users\Daniya\Desktop\MinecraftLauncher.exe ")


while True:
    makeSomething(command())

pygame.init()
gray = (119, 118, 110)
black = (0, 0, 0)
red = (255, 0, 0)
green = (0, 200, 0)
blue = (0, 0, 200)
teal = (0, 128, 128)
gold = (255, 215, 0)
korich = (139, 69, 19)
white = (255, 255, 255)
bright_red = (255, 0, 0)
bright_green = (0, 255, 0)
bright_blue = (0, 0, 255)
display_width = 800
display_height = 600

gamedisplays = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption("More games")
clock = pygame.time.Clock()
carimg = pygame.image.load('car1.jpg')
backgroundpic = pygame.image.load("download12.jpg")
yellow_strip = pygame.image.load("yellow strip.jpg")
strip = pygame.image.load("strip.jpg")
intro_background = pygame.image.load("background.jpg")
instruction_background = pygame.image.load("background2.jpg")
car_width = 56
pause = False


def intro_loop():
    intro = True
    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                sys.exit()
        gamedisplays.blit(intro_background, (0, 0))
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("MoreGames", largetext)
        TextRect.center = (400, 100)
        gamedisplays.blit(TextSurf, TextRect)
        button("МАШИНКИ", 50, 150, 120, 50, gold, white, "play")
        button("ИНСТРУКЦИЯ", 50, 370, 165, 50, teal, white, "intro")
        button("ТРАМП", 50, 315, 100, 50, blue, white, "trump")
        button("ЛОВКАЧ", 50, 205, 100, 50, green, white, "igra")
        button("ЗМЕЙКА", 50, 260, 100, 50, korich, white, "zmea")
        button("ВЫХОД", 50, 425, 100, 50, red, white, "quit")
        pygame.display.update()
        clock.tick(50)


def button(msg, x, y, w, h, ic, ac, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(gamedisplays, ac, (x, y, w, h))
        if click[0] == 1 and action != None:
            if action == "play":
                countdown()
            elif action == "quit":
                pygame.quit()
                quit()
                sys.exit()
            elif action == "intro":
                introduction()
            elif action == "menu":
                intro_loop()
            elif action == "pause":
                paused()
            elif action == "unpause":
                unpaused()
            if action == "igra":
                igra()
            if action == "zmea":
                zmea()
            if action == "trump":
                trump()


    else:
        pygame.draw.rect(gamedisplays, ic, (x, y, w, h))
    smalltext = pygame.font.Font("freesansbold.ttf", 20)
    textsurf, textrect = text_objects(msg, smalltext)
    textrect.center = ((x + (w / 2)), (y + (h / 2)))
    gamedisplays.blit(textsurf, textrect)


def introduction():
    introduction = True
    while introduction:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                sys.exit()
        gamedisplays.blit(instruction_background, (0, 0))
        largetext = pygame.font.Font('freesansbold.ttf', 80)
        smalltext = pygame.font.Font('freesansbold.ttf', 20)
        mediumtext = pygame.font.Font('freesansbold.ttf', 40)
        textSurf, textRect = text_objects("Эти самые лучшие игры предназначены для Яндекс Лицеистов", smalltext)
        textRect.center = ((350), (200))
        TextSurf, TextRect = text_objects("Инструкция", largetext)
        TextRect.center = ((400), (100))
        gamedisplays.blit(TextSurf, TextRect)
        gamedisplays.blit(textSurf, textRect)
        stextSurf, stextRect = text_objects("Кнопка налево : Движение налево", smalltext)
        stextRect.center = ((190), (400))
        hTextSurf, hTextRect = text_objects("Кнопка направо : Движение вправо", smalltext)
        hTextRect.center = ((190), (450))
        atextSurf, atextRect = text_objects("A : Принять", smalltext)
        atextRect.center = ((150), (500))
        rtextSurf, rtextRect = text_objects("B : Назад ", smalltext)
        rtextRect.center = ((150), (550))
        ptextSurf, ptextRect = text_objects("P : Пауза  ", smalltext)
        ptextRect.center = ((150), (350))
        sTextSurf, sTextRect = text_objects("Управление", mediumtext)
        sTextRect.center = ((350), (300))
        gamedisplays.blit(sTextSurf, sTextRect)
        gamedisplays.blit(stextSurf, stextRect)
        gamedisplays.blit(hTextSurf, hTextRect)
        gamedisplays.blit(atextSurf, atextRect)
        gamedisplays.blit(rtextSurf, rtextRect)
        gamedisplays.blit(ptextSurf, ptextRect)
        button("НАЗАД", 600, 450, 100, 50, blue, white, "menu")
        pygame.display.update()
        clock.tick(30)


def uliza():
    WINDOWWIDTH = 600
    WINDOWHEIGHT = 600
    TEXTCOLOR = (0, 0, 0)
    BACKGROUNDCOLOR = (255, 255, 255)
    FPS = 60
    BADDIEMINSIZE = 10
    BADDIEMAXSIZE = 40
    BADDIEMINSPEED = 1
    BADDIEMAXSPEED = 8
    ADDNEWBADDIERATE = 6
    PLAYERMOVERATE = 5


def trump():
    trump = True

    while trump:
        for event in pygame.event.get():
            if event.key == K_ESCAPE:
                intro_loop()
            if event.type == pygame.QUIT:
                pygame.quit()

        win = pygame.display.set_mode((500, 500))

        pygame.display.set_caption("Maksim game")

        x = 50
        y = 435
        widht = 60
        height = 71
        speed = 5
        clock = pygame.time.Clock()

        isJump = False
        JumpCount = 10

        left = False
        right = False
        animCount = 0

        walkRight = [pygame.image.load('right_1.png'),
                     pygame.image.load('right_2.png'),
                     pygame.image.load('right_3.png'),
                     pygame.image.load('right_4.png'),
                     pygame.image.load('right_5.png'),
                     pygame.image.load('right_6.png')]

        walkLeft = [pygame.image.load('left_1.png'),
                    pygame.image.load('left_2.png'),
                    pygame.image.load('left_3.png'),
                    pygame.image.load('left_4.png'),
                    pygame.image.load('left_5.png'),
                    pygame.image.load('left_6.png')]

        bg = pygame.image.load('bg.jpg')
        playerStand = pygame.image.load('idle.png')

        def drawWindow():
            global animCount
            win.blit(bg, (0, 0))
            animCount = 0

            if animCount + 1 >= 30:
                animCount = 0

            if left:
                win.blit(walkLeft[animCount // 5], (x, y))
                animCount += 1
            elif right:
                win.blit(walkRight[animCount // 5], (x, y))
                animCount += 1
            else:
                win.blit(playerStand, (x, y))

            pygame.display.update()

        run = True
        while run:
            clock.tick(30)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and x > 5:
                x -= speed
                left = True
                right = True
            elif keys[pygame.K_RIGHT] and x < 500 - widht - 5:
                x += speed
                left = False
                right = True
            else:
                left = False
                right = False
            if not (isJump):
                if keys[pygame.K_SPACE]:
                    isJump = True

            else:
                if JumpCount >= -10:
                    if JumpCount < 0:
                        y += (JumpCount ** 2) / 2
                    else:
                        y -= (JumpCount ** 2) / 2
                    JumpCount -= 1
                else:
                    isJump = False
                    JumpCount = 10

            drawWindow()
        pygame.quit()


def zmea():
    zmea = True

    while zmea:
        for event in pygame.event.get():
            if event.key == K_ESCAPE:
                intro_loop()
            if event.type == pygame.QUIT:
                pygame.quit()

        class Game():
            def __init__(self):
                # задаем размеры экрана
                self.screen_width = 720
                self.screen_height = 460

                # необходимые цвета
                self.red = pygame.Color(255, 0, 0)
                self.green = pygame.Color(0, 255, 0)
                self.black = pygame.Color(0, 0, 0)
                self.white = pygame.Color(192, 192, 192)
                self.brown = pygame.Color(165, 42, 42)
                intro_background = pygame.image.load("background.jpg")
                gamedisplays.blit(intro_background, (0, 0))

                # Frame per second controller
                # будет задавать количество кадров в секунду
                self.fps_controller = pygame.time.Clock()

                # переменная для оторбражения результата
                # (сколько еды съели)
                self.score = 0

            def init_and_check_for_errors(self):
                """Начальная функция для инициализации и
                   проверки как запустится pygame"""
                check_errors = pygame.init()
                if check_errors[1] > 0:
                    sys.exit()
                else:
                    print('Ok')

            def set_surface_and_title(self):
                """Задаем surface(поверхность поверх которой будет все рисоваться)
                и устанавливаем загаловок окна"""
                self.play_surface = pygame.display.set_mode((
                    self.screen_width, self.screen_height))
                pygame.display.set_caption('Игра Змейка')

            def event_loop(self, change_to):
                """Функция для отслеживания нажатий клавиш игроком"""

                # запускаем цикл по ивентам
                for event in pygame.event.get():
                    # если нажали клавишу
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RIGHT or event.key == ord('d'):
                            change_to = "RIGHT"
                        elif event.key == pygame.K_LEFT or event.key == ord('a'):
                            change_to = "LEFT"
                        elif event.key == pygame.K_UP or event.key == ord('w'):
                            change_to = "UP"
                        elif event.key == pygame.K_DOWN or event.key == ord('s'):
                            change_to = "DOWN"
                        # нажали escape
                        elif event.key == pygame.K_ESCAPE:
                            pygame.quit()
                            sys.exit()
                return change_to

            def refresh_screen(self):
                """обновляем экран и задаем фпс"""
                pygame.display.flip()
                game.fps_controller.tick(11)

            def show_score(self, choice=1):
                """Отображение результата"""
                s_font = pygame.font.SysFont('monaco', 24)
                s_surf = s_font.render(
                    'Очки: {0}'.format(self.score), True, self.black)
                s_rect = s_surf.get_rect()
                # дефолтный случай отображаем результат слева сверху
                if choice == 1:
                    s_rect.midtop = (80, 10)
                # при game_overe отображаем результат по центру
                # под надписью game over
                else:
                    s_rect.midtop = (360, 120)
                # рисуем прямоугольник поверх surface
                self.play_surface.blit(s_surf, s_rect)

            def game_over(self):
                """Функция для вывода надписи Game Over и результатов
                в случае завершения игры и выход из игры"""
                go_font = pygame.font.SysFont('monaco', 72)
                go_surf = go_font.render('Game over', True, self.red)
                go_rect = go_surf.get_rect()
                go_rect.midtop = (360, 15)
                self.play_surface.blit(go_surf, go_rect)
                self.show_score(0)
                pygame.display.flip()
                time.sleep(3)
                pygame.quit()
                sys.exit()

        class Snake():
            def __init__(self, snake_color):
                # важные переменные - позиция головы змеи и его тела
                self.snake_head_pos = [100, 50]  # [x, y]
                # начальное тело змеи состоит из трех сегментов
                # голова змеи - первый элемент, хвост - последний
                self.snake_body = [[100, 50], [90, 50], [80, 50]]
                self.snake_color = snake_color
                # направление движение змеи, изначально
                # зададимся вправо
                self.direction = "RIGHT"
                # куда будет меняться напрвление движения змеи
                # при нажатии соответствующих клавиш
                self.change_to = self.direction

            def validate_direction_and_change(self):
                """Изменияем направление движения змеи только в том случае,
                если оно не прямо противоположно текущему"""
                if any((self.change_to == "RIGHT" and not self.direction == "LEFT",
                        self.change_to == "LEFT" and not self.direction == "RIGHT",
                        self.change_to == "UP" and not self.direction == "DOWN",
                        self.change_to == "DOWN" and not self.direction == "UP")):
                    self.direction = self.change_to

            def change_head_position(self):
                """Изменияем положение головы змеи"""
                if self.direction == "RIGHT":
                    self.snake_head_pos[0] += 10
                elif self.direction == "LEFT":
                    self.snake_head_pos[0] -= 10
                elif self.direction == "UP":
                    self.snake_head_pos[1] -= 10
                elif self.direction == "DOWN":
                    self.snake_head_pos[1] += 10

            def snake_body_mechanism(
                    self, score, food_pos, screen_width, screen_height):
                # если вставлять просто snake_head_pos,
                # то на всех трех позициях в snake_body
                # окажется один и тот же список с одинаковыми координатами
                # и мы будем управлять змеей из одного квадрата
                self.snake_body.insert(0, list(self.snake_head_pos))
                # если съели еду
                if (self.snake_head_pos[0] == food_pos[0] and
                        self.snake_head_pos[1] == food_pos[1]):
                    # если съели еду то задаем новое положение еды случайным
                    # образом и увеличивем score на один
                    food_pos = [random.randrange(1, screen_width / 10) * 10,
                                random.randrange(1, screen_height / 10) * 10]
                    score += 1
                else:
                    # если не нашли еду, то убираем последний сегмент,
                    # если этого не сделать, то змея будет постоянно расти
                    self.snake_body.pop()
                return score, food_pos

            def draw_snake(self, play_surface, surface_color):
                """Отображаем все сегменты змеи"""
                play_surface.fill(surface_color)
                for pos in self.snake_body:
                    # pygame.Rect(x,y, sizex, sizey)
                    pygame.draw.rect(
                        play_surface, self.snake_color, pygame.Rect(
                            pos[0], pos[1], 10, 10))

            def check_for_boundaries(self, game_over, screen_width, screen_height):
                """Проверка, что столкунлись с концами экрана или сами с собой
                (змея закольцевалась)"""
                if any((
                        self.snake_head_pos[0] > screen_width - 10
                        or self.snake_head_pos[0] < 0,
                        self.snake_head_pos[1] > screen_height - 10
                        or self.snake_head_pos[1] < 0
                )):
                    game_over()
                for block in self.snake_body[1:]:
                    # проверка на то, что первый элемент(голова) врезался в
                    # любой другой элемент змеи (закольцевались)
                    if (block[0] == self.snake_head_pos[0] and
                            block[1] == self.snake_head_pos[1]):
                        game_over()

        class Food():
            def __init__(self, food_color, screen_width, screen_height):
                """Инит еды"""
                self.food_color = food_color
                self.food_size_x = 10
                self.food_size_y = 10
                self.food_pos = [random.randrange(1, screen_width / 10) * 10,
                                 random.randrange(1, screen_height / 10) * 10]

            def draw_food(self, play_surface):
                """Отображение еды"""
                pygame.draw.rect(
                    play_surface, self.food_color, pygame.Rect(
                        self.food_pos[0], self.food_pos[1],
                        self.food_size_x, self.food_size_y))

        game = Game()
        snake = Snake(game.green)
        food = Food(game.brown, game.screen_width, game.screen_height)

        game.init_and_check_for_errors()
        game.set_surface_and_title()

        while True:
            snake.change_to = game.event_loop(snake.change_to)

            snake.validate_direction_and_change()
            snake.change_head_position()
            game.score, food.food_pos = snake.snake_body_mechanism(
                game.score, food.food_pos, game.screen_width, game.screen_height)
            snake.draw_snake(game.play_surface, game.white)

            food.draw_food(game.play_surface)

            snake.check_for_boundaries(
                game.game_over, game.screen_width, game.screen_height)

            game.show_score()
            game.refresh_screen()


def igra():
    igra = True

    while igra:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                sys.exit()
        WINDOWWIDTH = 800
        WINDOWHEIGHT = 600
        TEXTCOLOR = (0, 0, 0)
        BACKGROUNDCOLOR = (255, 255, 255)
        FPS = 60
        BADDIEMINSIZE = 10
        BADDIEMAXSIZE = 40
        BADDIEMINSPEED = 1
        BADDIEMAXSPEED = 8
        ADDNEWBADDIERATE = 6
        PLAYERMOVERATE = 5
        intro_background = pygame.image.load("fon.jpg")
        button("Главное меню", 550, 450, 200, 50, red, white, "menu")

        def terminate():
            pygame.quit()
            sys.exit()

        def waitForPlayerToPressKey():
            while True:
                for event in pygame.event.get():
                    if event.type == QUIT:
                        terminate()
                    if event.type == KEYDOWN:
                        if event.key == K_ESCAPE:  # Pressing ESC quits.
                            pygame.mixer.music.stop()
                            gameOverSound.stop()
                            intro_loop()
                            mouse = pygame.mouse.get_pos()
                            windowSurface.blit(mouse)
                            pygame.mixer.music.stop()
                            gameOverSound.stop()
                        return

        def playerHasHitBaddie(playerRect, baddies):
            for b in baddies:
                if playerRect.colliderect(b['rect']):
                    return True
            return False

        def drawText(text, font, surface, x, y):
            textobj = font.render(text, 1, TEXTCOLOR)
            textrect = textobj.get_rect()
            textrect.topleft = (x, y)
            surface.blit(textobj, textrect)
            # Set up pygame, the window, and the mouse cursor.

        pygame.init()
        mainClock = pygame.time.Clock()
        windowSurface = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
        pygame.display.set_caption('Ловкач')
        button("Главное меню", 550, 450, 200, 50, red, white, "menu")
        pygame.mouse.set_visible(False)
        # Set up the fonts.
        font = pygame.font.SysFont(None, 48)
        # Set up sounds.
        gameOverSound = pygame.mixer.Sound('123.mp3')
        pygame.mixer.music.load('1234.mp3')
        # Set up images.
        playerImage = pygame.image.load('car8.jpg')
        playerRect = playerImage.get_rect()
        baddieImage = pygame.image.load('uliza1.jpg')
        # Show the "Start" screen.
        windowSurface.fill(BACKGROUNDCOLOR)
        windowSurface.blit(intro_background, (0, 0))
        drawText('Ловкач', font, windowSurface, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
        drawText('Нажмите, чтобы начать.', font, windowSurface, (WINDOWWIDTH / 4.2) - 30, (WINDOWHEIGHT / 3) + 50)
        pygame.display.update()
        waitForPlayerToPressKey()
        topScore = 0
        while True:
            # Set up the start of the game.
            baddies = []
            score = 0
            playerRect.topleft = (WINDOWWIDTH / 2, WINDOWHEIGHT - 50)
            moveLeft = moveRight = moveUp = moveDown = False
            reverseCheat = slowCheat = False
            windowSurface.blit(intro_background, (0, 0))
            baddieAddCounter = 0
            clock = pygame.time.Clock()
            pygame.mixer.music.play(-1, 0.0)
            while True:  # The game loop runs while the game part is playing.
                score += 1  # Increase score.
                for event in pygame.event.get():
                    if event.type == QUIT:
                        terminate()
                    if event.type == KEYDOWN:
                        if event.key == K_z:
                            reverseCheat = True
                        if event.key == K_x:
                            slowCheat = True
                        if event.key == K_LEFT or event.key == K_a:
                            moveRight = False
                            moveLeft = True
                        if event.key == K_RIGHT or event.key == K_d:
                            moveLeft = False
                            moveRight = True
                        if event.key == K_UP or event.key == K_w:
                            moveDown = False
                            moveUp = True
                        if event.key == K_DOWN or event.key == K_s:
                            moveUp = False
                            moveDown = True
                    if event.type == KEYUP:
                        if event.key == K_z:
                            reverseCheat = False
                            score = 0
                        if event.key == K_x:
                            slowCheat = False
                            score = 0
                        if event.key == K_ESCAPE:
                            terminate()
                        if event.key == K_LEFT or event.key == K_a:
                            moveLeft = False
                        if event.key == K_RIGHT or event.key == K_d:
                            moveRight = False
                        if event.key == K_UP or event.key == K_w:
                            moveUp = False
                        if event.key == K_DOWN or event.key == K_s:
                            moveDown = False
                    if event.type == MOUSEMOTION:
                        # If the mouse moves, move the player where to the cursor.
                        playerRect.centerx = event.pos[0]
                        playerRect.centery = event.pos[1]
                        # Add new baddies at the top of the screen, if needed.
                if not reverseCheat and not slowCheat:
                    baddieAddCounter += 1
                if baddieAddCounter == ADDNEWBADDIERATE:
                    baddieAddCounter = 0
                    baddieSize = random.randint(BADDIEMINSIZE, BADDIEMAXSIZE)
                    newBaddie = {
                        'rect': pygame.Rect(random.randint(0, WINDOWWIDTH - baddieSize), 0 - baddieSize, baddieSize,
                                            baddieSize),
                        'speed': random.randint(BADDIEMINSPEED, BADDIEMAXSPEED),
                        'surface': pygame.transform.scale(baddieImage, (baddieSize, baddieSize)),
                    }
                    baddies.append(newBaddie)
                    # Move the player around.
                if moveLeft and playerRect.left > 0:
                    playerRect.move_ip(-1 * PLAYERMOVERATE, 0)
                if moveRight and playerRect.right < WINDOWWIDTH:
                    playerRect.move_ip(PLAYERMOVERATE, 0)
                if moveUp and playerRect.top > 0:
                    playerRect.move_ip(0, -1 * PLAYERMOVERATE)
                if moveDown and playerRect.bottom < WINDOWHEIGHT:
                    playerRect.move_ip(0, PLAYERMOVERATE)
                    # Move the baddies down.
                for b in baddies:
                    if not reverseCheat and not slowCheat:
                        b['rect'].move_ip(0, b['speed'])
                    elif reverseCheat:
                        b['rect'].move_ip(0, -5)
                    elif slowCheat:
                        b['rect'].move_ip(0, 1)
                        # Delete baddies that have fallen past the bottom.
                for b in baddies[:]:
                    if b['rect'].top > WINDOWHEIGHT:
                        baddies.remove(b)
                        # Draw the game world on the window.
                windowSurface.fill(BACKGROUNDCOLOR)
                windowSurface.blit(intro_background, (0, 0))
                # Draw the score and top score.
                drawText('Очки: %s' % (score), font, windowSurface, 10, 0)
                drawText('Лучшие очки: %s' % (topScore), font, windowSurface, 10, 40)
                # Draw the player's rectangle.
                windowSurface.blit(playerImage, playerRect)
                # Draw each baddie.
                for b in baddies:
                    windowSurface.blit(b['surface'], b['rect'])
                pygame.display.update()
                # Check if any of the baddies have hit the player.
                if playerHasHitBaddie(playerRect, baddies):
                    if score > topScore:
                        topScore = score  # set new top score
                    break
                mainClock.tick(FPS)
                # Stop the game and show the "Game Over" screen.
            windowSurface.blit(intro_background, (0, 0))
            pygame.mixer.music.stop()
            gameOverSound.play()
            drawText('GAME OVER', font, windowSurface, (WINDOWWIDTH / 4), (WINDOWHEIGHT / 3))
            drawText('Нажмите, чтобы начать заново.', font, windowSurface, (WINDOWWIDTH / 7) - 80,
                     (WINDOWHEIGHT / 3) + 50)
            pygame.display.update()
            if event.type == pygame.MOUSEMOTION:
                cursor_pos = event.pos
            mouse = pygame.mouse.get_pos()
            windowSurface.blit(playerImage, playerRect)
            waitForPlayerToPressKey()
            gameOverSound.stop()
        pygame.display.update()


def paused():
    global pause

    while pause:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                sys.exit()
        gamedisplays.blit(instruction_background, (0, 0))
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("НА ПАУЗЕ", largetext)
        TextRect.center = ((display_width / 2), (display_height / 2))
        gamedisplays.blit(TextSurf, TextRect)
        button("Продолжить", 150, 450, 150, 50, green, bright_green, "unpause")
        button("Рестарт", 350, 450, 150, 50, blue, bright_blue, "play")
        button("Главное меню", 550, 450, 200, 50, red, bright_red, "menu")
        pygame.display.update()
        clock.tick(30)


def unpaused():
    global pause
    pause = False


def countdown_background():
    font = pygame.font.SysFont(None, 25)
    x = (display_width * 0.45)
    y = (display_height * 0.8)
    gamedisplays.blit(backgroundpic, (0, 0))
    gamedisplays.blit(backgroundpic, (0, 200))
    gamedisplays.blit(backgroundpic, (0, 400))
    gamedisplays.blit(backgroundpic, (900, 0))
    gamedisplays.blit(backgroundpic, (900, 200))
    gamedisplays.blit(backgroundpic, (900, 400))
    gamedisplays.blit(yellow_strip, (400, 100))
    gamedisplays.blit(yellow_strip, (400, 200))
    gamedisplays.blit(yellow_strip, (400, 300))
    gamedisplays.blit(yellow_strip, (400, 400))
    gamedisplays.blit(yellow_strip, (400, 100))
    gamedisplays.blit(yellow_strip, (400, 500))
    gamedisplays.blit(yellow_strip, (400, 0))
    gamedisplays.blit(yellow_strip, (400, 600))
    gamedisplays.blit(strip, (120, 200))
    gamedisplays.blit(strip, (120, 0))
    gamedisplays.blit(strip, (120, 100))
    gamedisplays.blit(strip, (680, 100))
    gamedisplays.blit(strip, (680, 0))
    gamedisplays.blit(strip, (680, 200))
    gamedisplays.blit(carimg, (x, y))
    text = font.render("Машины: 0", True, black)
    score = font.render("Очки: 0", True, red)
    gamedisplays.blit(text, (0, 50))
    gamedisplays.blit(score, (0, 30))
    button("ПАУЗА", 650, 0, 150, 50, blue, bright_blue, "pause")


def countdown():
    countdown = True

    while countdown:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                sys.exit()
        gamedisplays.fill(gray)
        countdown_background()
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("3", largetext)
        TextRect.center = ((display_width / 2), (display_height / 2))
        gamedisplays.blit(TextSurf, TextRect)
        pygame.display.update()
        clock.tick(1)
        gamedisplays.fill(gray)
        countdown_background()
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("2", largetext)
        TextRect.center = ((display_width / 2), (display_height / 2))
        gamedisplays.blit(TextSurf, TextRect)
        pygame.display.update()
        clock.tick(1)
        gamedisplays.fill(gray)
        countdown_background()
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("1", largetext)
        TextRect.center = ((display_width / 2), (display_height / 2))
        gamedisplays.blit(TextSurf, TextRect)
        pygame.display.update()
        clock.tick(1)
        gamedisplays.fill(gray)
        countdown_background()
        largetext = pygame.font.Font('freesansbold.ttf', 115)
        TextSurf, TextRect = text_objects("GO!!!", largetext)
        TextRect.center = ((display_width / 2), (display_height / 2))
        gamedisplays.blit(TextSurf, TextRect)
        pygame.display.update()
        clock.tick(1)
        game_loop()


def obstacle(obs_startx, obs_starty, obs):
    if obs == 0:
        obs_pic = pygame.image.load("car.jpg")
    elif obs == 1:
        obs_pic = pygame.image.load("car1.jpg")
    elif obs == 2:
        obs_pic = pygame.image.load("car2.jpg")
    elif obs == 3:
        obs_pic = pygame.image.load("car4.jpg")
    elif obs == 4:
        obs_pic = pygame.image.load("car5.jpg")
    elif obs == 5:
        obs_pic = pygame.image.load("car6.jpg")
    elif obs == 6:
        obs_pic = pygame.image.load("car7.jpg")
    gamedisplays.blit(obs_pic, (obs_startx, obs_starty))


def score_system(passed, score):
    font = pygame.font.SysFont(None, 25)
    text = font.render("Машины: " + str(passed), True, black)
    score = font.render("Очки: " + str(score), True, red)
    gamedisplays.blit(text, (0, 50))
    gamedisplays.blit(score, (0, 30))


def text_objects(text, font):
    textsurface = font.render(text, True, black)
    return textsurface, textsurface.get_rect()


def message_display(text):
    largetext = pygame.font.Font("freesansbold.ttf", 80)
    textsurf, textrect = text_objects(text, largetext)
    textrect.center = ((display_width / 2), (display_height / 2))
    gamedisplays.blit(textsurf, textrect)
    pygame.display.update()
    time.sleep(3)
    game_loop()


def crash():
    message_display("ВЫ ПРОИГРАЛИ")


def background():
    gamedisplays.blit(backgroundpic, (0, 0))
    gamedisplays.blit(backgroundpic, (0, 200))
    gamedisplays.blit(backgroundpic, (0, 400))
    gamedisplays.blit(backgroundpic, (700, 0))
    gamedisplays.blit(backgroundpic, (700, 200))
    gamedisplays.blit(backgroundpic, (700, 400))
    gamedisplays.blit(yellow_strip, (400, 0))
    gamedisplays.blit(yellow_strip, (400, 100))
    gamedisplays.blit(yellow_strip, (400, 200))
    gamedisplays.blit(yellow_strip, (400, 300))
    gamedisplays.blit(yellow_strip, (400, 400))
    gamedisplays.blit(yellow_strip, (400, 500))
    gamedisplays.blit(strip, (120, 0))
    gamedisplays.blit(strip, (120, 100))
    gamedisplays.blit(strip, (120, 200))
    gamedisplays.blit(strip, (680, 0))
    gamedisplays.blit(strip, (680, 100))
    gamedisplays.blit(strip, (680, 200))


def car(x, y):
    gamedisplays.blit(carimg, (x, y))


def game_loop():
    global pause
    x = (display_width * 0.45)
    y = (display_height * 0.8)
    x_change = 0
    obstacle_speed = 9
    obs = 0
    y_change = 0
    obs_startx = random.randrange(200, (display_width - 200))
    obs_starty = -750
    obs_width = 56
    obs_height = 125
    passed = 0
    level = 0
    score = 0
    y2 = 7
    fps = 120

    bumped = False
    while not bumped:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x_change = -5
                if event.key == pygame.K_RIGHT:
                    x_change = 5
                if event.key == pygame.K_a:
                    obstacle_speed += 2
                if event.key == pygame.K_b:
                    obstacle_speed -= 2
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    x_change = 0

        x += x_change
        pause = True
        gamedisplays.fill(gray)

        rel_y = y2 % backgroundpic.get_rect().width
        gamedisplays.blit(backgroundpic, (0, rel_y - backgroundpic.get_rect().width))
        gamedisplays.blit(backgroundpic, (700, rel_y - backgroundpic.get_rect().width))
        if rel_y < 800:
            gamedisplays.blit(backgroundpic, (0, rel_y))
            gamedisplays.blit(backgroundpic, (700, rel_y))
            gamedisplays.blit(yellow_strip, (400, rel_y))
            gamedisplays.blit(yellow_strip, (400, rel_y + 100))
            gamedisplays.blit(yellow_strip, (400, rel_y + 200))
            gamedisplays.blit(yellow_strip, (400, rel_y + 300))
            gamedisplays.blit(yellow_strip, (400, rel_y + 400))
            gamedisplays.blit(yellow_strip, (400, rel_y + 500))
            gamedisplays.blit(yellow_strip, (400, rel_y - 100))
            gamedisplays.blit(strip, (120, rel_y - 200))
            gamedisplays.blit(strip, (120, rel_y + 20))
            gamedisplays.blit(strip, (120, rel_y + 30))
            gamedisplays.blit(strip, (680, rel_y - 100))
            gamedisplays.blit(strip, (680, rel_y + 20))
            gamedisplays.blit(strip, (680, rel_y + 30))

        y2 += obstacle_speed

        obs_starty -= (obstacle_speed / 4)
        obstacle(obs_startx, obs_starty, obs)
        obs_starty += obstacle_speed
        car(x, y)
        score_system(passed, score)
        if x > 690 - car_width or x < 110:
            crash()
        if x > display_width - (car_width + 110) or x < 110:
            crash()
        if obs_starty > display_height:
            obs_starty = 0 - obs_height
            obs_startx = random.randrange(170, (display_width - 170))
            obs = random.randrange(0, 7)
            passed = passed + 1
            score = passed * 10
            if int(passed) % 10 == 0:
                level = level + 1
                obstacle_speed + 2
                largetext = pygame.font.Font("freesansbold.ttf", 80)
                textsurf, textrect = text_objects("LEVEL" + str(level), largetext)
                textrect.center = ((display_width / 2), (display_height / 2))
                gamedisplays.blit(textsurf, textrect)
                pygame.display.update()
                time.sleep(2)

        if y < obs_starty + obs_height:
            if x > obs_startx and x < obs_startx + obs_width or x + car_width > obs_startx and x + car_width < obs_startx + obs_width:
                crash()
        button("ПАУЗА", 650, 0, 150, 50, blue, bright_blue, "pause")
        pygame.display.update()
        clock.tick(60)


intro_loop()
game_loop()
igra()
pygame.quit()
quit()
